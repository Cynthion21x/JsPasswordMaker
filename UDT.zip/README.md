# UltimateDevelopmentTool
Ultimate Development Tool has an adblocker which runs behind the scenes, and can block all ads not just on sites, on youtube as well, it uses a cookie, (Not a malicious one!) to look at browsing traffic to and from your machine and check for ads(it does not do anything else with your browsing traffic), it also has:

Cookie Viewer
Tracker Blocker
Lots Of Developer Tools
Password Generator
HTTP Request Viewer
