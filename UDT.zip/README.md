# UltimateDevelopmentTool
a extention here to help improve your mozila firefox developing experience. This add on includes an adblocking feture as well as various tools to help you while developing using firefox. We use cookies to improve our ad blocking to direct ALL internet traffic to your pc. That means we can extend our ad blocking beond firefox from yoyr browser!
